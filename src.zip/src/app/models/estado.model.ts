export class Estado {
    id!: number;
    nome!: string;
    sigla!: string;
}
